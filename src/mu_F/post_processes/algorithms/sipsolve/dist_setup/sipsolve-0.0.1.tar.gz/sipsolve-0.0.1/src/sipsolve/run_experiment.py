# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


import logging
import time

import hydra
import jax.numpy as jnp

from jax import config
from omegaconf import DictConfig

from sipsolve.problem_management import SubProblemInterface, P1Manager, P2Manager
from sipsolve.discretisation import DiscretisationConfig
from sipsolve.interface import SubProblemIteration
from sipsolve.metrics import ConstraintSatisfaction, Volume, PenaltyViolation, Metrics
from sipsolve.visualisation import visualiser
from sipsolve.constraints.auxiliary import get_user_feedback_constraint_system
from sipsolve.utils import bounds_from_config, scaling_schemes
from sipsolve.problems.functions import problem_evaluators, problems_dict
from sipsolve.constants import MIN_SAMPLES


def experiment(
    cfg: DictConfig, 
    previous_solution: jnp.ndarray | None = None, 
    user_feedback: jnp.ndarray | None = None, 
    iteration: int = 0
):
    """This runs the main experiment loop for the SIP solver"""
    # Load the constraint function
    g_x, penalty_fns = get_constraint_functions(
        cfg, 
        previous_solution=previous_solution, 
        user_feedback=user_feedback, 
        return_as_penalties=cfg.constraints.auxiliary_constraints.as_penalty
    )

    # Define the bounds of the fixed constraint set for P1
    x_bounds = bounds_from_config(cfg, cfg.discretisation.bounds)
    d_bounds = bounds_from_config(cfg, cfg.policy.bounds, bound_factor=cfg.policy.bound_factor)
    n_g = max(int(cfg.discretisation.num_samples_per_dim * cfg.constraints.problem_dim), MIN_SAMPLES)
    # create the discretisation scheme
    discretisation_scheme = DiscretisationConfig(
        n_g, bounds=x_bounds, method=cfg.discretisation.method
    )

    # Define the scaling function
    scaling_fn = scaling_schemes[cfg.scaling.scheme]

    # Create the model manager
    p1_manager = P1Manager(
        cfg, constraints=g_x, discretisation_scheme=discretisation_scheme, 
        scaling_fn=scaling_fn, penalty_functions=penalty_fns
    )
    p2_manager = P2Manager(
        cfg, constraints=g_x, scaling_fn=scaling_fn
    )
    
    # Create the Subproblem Manager
    optimizer = SubProblemInterface(
        cfg,
        constraint_manager=p1_manager,
        feasibility_manager=p2_manager,
        d_bounds=d_bounds,
        x_bounds=x_bounds,
        n_g=len(g_x)
    )

    # Create the interface
    start_time = time.time()
    interface_instance = SubProblemIteration(cfg=cfg, optimizer=optimizer)

    # Run the experiment
    final_optimizer, final_timing_metrics = interface_instance.create()
    logging.info(f"Experiment completed in {time.time() - start_time:.2f} seconds")

    # get optimizer and objects for metrics
    constraint_model = problem_evaluators[cfg.constraints.target_fn].create()
    solution_bounds = final_optimizer.feasibility_manager.relaxation_data
    constraint_fn = lambda x: jnp.array(
        [[cons(y) for cons in constraint_model] for y in x]
    ).squeeze()
    pfn = p1_manager.get_penalty_functions(p1_manager.penalty_set)
    
    # Define metrics to evaluate
    constraint_metrics = ConstraintSatisfaction(
        cfg, constraint_fn, threshold=0.0, confidence=cfg.constraints.confidence
    )
    volume_metric = Volume()
    penalty_violation_metric = PenaltyViolation(penalty_fn=pfn)
    metrics = Metrics(
        metrics=[constraint_metrics, volume_metric, penalty_violation_metric],
        names=['constraints', 'volume', 'penalty_violation']
    )
    final_metrics = metrics.compute(solution_bounds)
    logging.info("Final Metrics:")
    logging.info(
        f"Constraint Satisfaction (Lower Bound, Sample Average, Upper Bound): {final_metrics['constraints'][0]}"
    )
    logging.info(
        f"Volume: {final_metrics['volume']}"
    )
    logging.info(
        f"Penalty Set Violation: {final_metrics['penalty_violation']}"
    )
    logging.info(f"Solver Timing Metrics:")
    for key, value in final_timing_metrics.get_results().items():
        logging.info(f"{key}: {value:.4f}")

    # Visualise the results
    if not cfg.validation.enable_visualisation:
        return final_optimizer, final_metrics
    else:
        visualiser_instance = visualiser(cfg, [constraint_fn, constraint_fn], x_bounds=d_bounds, iteration=iteration)
        visualiser_instance.plot(samples=final_metrics['constraints'][1])
        logging.info("Plotting complete.")

    return final_optimizer, final_metrics


def get_constraint_functions(cfg: DictConfig, previous_solution: jnp.ndarray | None = None, user_feedback: jnp.ndarray | None = None, return_as_penalties: bool = False):
    # Create the constraint function
    g_x = [problems_dict[cfg.constraints.target_fn]]
    if previous_solution is None:
        penalty_fns = []
    else:
        auxiliary_gx = get_user_feedback_constraint_system(
                cfg,
                n_decisions=cfg.constraints.problem_dim,
                user_feedback=user_feedback,
                prev_solution=previous_solution,
            )
        if return_as_penalties:
            penalty_fns = auxiliary_gx
        else:
            penalty_fns = auxiliary_gx
            g_x += penalty_fns
        logging.info("Using previous solution to restrict the solution space.")
    return g_x, penalty_fns if return_as_penalties else None

@hydra.main(version_base=None, config_path="config", config_name="main")
def main(cfg: DictConfig):
    experiment(cfg)


if __name__ == "__main__":
    config.update("jax_enable_x64", True)
    main()
