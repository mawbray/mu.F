# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from dataclasses import dataclass, field
import jax.numpy as jnp


@dataclass
class ConvergenceTracker:
    """Class to track convergence based on the change in solutions over iterations."""
    tolerance: float = 1e-6
    patience: int = 5
    solutions: list = field(default_factory=list)
    _steady_count: int = field(default=0, init=False)
    _converged: bool = field(default=False, init=False)

    def update(self, solution):
        self.solutions.append(jnp.array(solution))
        if len(self.solutions) < 2:
            return
        diff = jnp.linalg.norm(self.solutions[-1] - self.solutions[-2], ord=jnp.inf)
        if diff < self.tolerance:
            self._steady_count += 1
        else:
            self._steady_count = 0
        if self._steady_count >= self.patience:
            self._converged = True

    @property
    def has_converged(self):
        return self._converged

    def reset(self):
        self.solutions.clear()
        self._steady_count = 0
        self._converged = False