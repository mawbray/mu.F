# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


import time

import jax.numpy as jnp
import numpy as np
from casadi import DM, MX, Callback, Function, Sparsity
from jax import jacrev, jit, vmap

# NOTE currently callbacks are only set up for scalar valued functions
# i.e. functions that map R^n_x -> R
# Combined with reverse mode AD to get gradients
# This is roughly equivalent to reverse mode AD on vector valued functions
# i.e. functions that map R^n_x -> R^n_g but the implementation is different
# in this case we require (m-1) additional constraint evaluations to get the full Jacobian
# However, if we extend Callbacks to handle vector valued functions
# we can use forward mode AD to get Jacobians
# which may be more efficient in many cases (i.e. when n_x < n_g)


class JaxCasADiEvaluator(Callback):
    def __init__(self, t_in, t_out, model, set_init=False, opts={}):
        self.set_init = set_init
        self.opts = opts
        Callback.__init__(self)
        assert isinstance(t_in, list)
        self.t_in = t_in
        assert isinstance(t_out, list)
        self.t_out = t_out
        self.output_shapes = []
        self.construct("JaxCasADiEvaluator", {})
        self.refs = []
        self.model = model
        self.jitted_model = jit(self.model)
        self.jitted_grad_func = jit(
            jacrev(self.jitted_model)
        )

    def get_n_in(self):
        return len(self.t_in)

    def get_n_out(self):
        return len(self.t_out)

    def get_sparsity_in(self, i):
        tensor_shape = self.t_in[i].shape
        return Sparsity.dense(tensor_shape[0], tensor_shape[1])

    def get_sparsity_out(self, i):
        if i == 0 and not self.set_init:
            tensor_shape = self.opts["output_dim"]
        elif i == 0 and self.set_init:
            tensor_shape = self.opts["grad_dim"]
        else:
            tensor_shape = self.opts["output_dim"]
        return Sparsity.dense(tensor_shape[0], tensor_shape[1])

    def objective_func(self, x):
        x = jnp.atleast_2d(x)
        mean = self.model(x)
        return mean.squeeze()

    def eval(self, arg):
        updated_t = []
        for i, v in enumerate(self.t_in):
            if isinstance(arg[i], (MX, DM)):
                arg_np = np.array(arg[i].full()).reshape(v.shape)
            else:
                arg_np = np.array(arg[i]).reshape(v.shape)
            updated_t.append(jnp.array(arg_np))
        input_data = jnp.atleast_2d(updated_t[0]).reshape(1, -1)

        if len(arg) > 1:  # Gradient calculation
            grad_output = self.jitted_grad_func(input_data)
            selected_set = np.array(grad_output).reshape(
                self.opts["grad_dim"][0], self.opts["grad_dim"][1]
            )
        else:  # Function value
            out_ = self.jitted_model(input_data)
            selected_set = np.array(out_).reshape(
                (self.opts["output_dim"][0], self.opts["output_dim"][1])
            )
            if out_ is None:
                raise ValueError("Output from the model is None.")

        return [selected_set]

    def has_reverse(self, nadj):
        return nadj == 1

    def get_reverse(self, nadj, name, inames, onames, opts):
        adj_seed = [MX.sym("adj", *self.get_sparsity_out(i).shape) for i in range(self.get_n_out())]
        callback = JaxCasADiEvaluator(
            self.t_in + adj_seed, [self.t_out[0]], self.model, set_init=True, opts=self.opts
        )
        self.refs.append(callback)
        nominal_in = self.mx_in()
        nominal_out = self.mx_out()
        adj_seed = self.mx_out()
        casadi_bal = callback.call(nominal_in + adj_seed)
        return Function(name, nominal_in + nominal_out + adj_seed, casadi_bal, inames, onames)


class ScalarFn(JaxCasADiEvaluator):
    def __init__(self, model, opts={}):
        X = MX.sym("X", opts["grad_dim"][0], 1)

        @jit
        def f_k(input_dat, get_grad_val=None):
            xf_tensor = jnp.array(input_dat)
            if get_grad_val is not None:
                mean = self.objective_func(xf_tensor)
            # Note: JAX automatically handles gradient computation
            else:
                mean = self.objective_func(xf_tensor)
            return mean, None  # Return None for grad_mean as JAX handles it differently

        JaxCasADiEvaluator.__init__(self, [X], [f_k], model, opts=opts)
        self.counter = 0
        self.time = 0

    def eval(self, arg):
        self.counter += 1
        t0 = time.time()
        ret = JaxCasADiEvaluator.eval(self, arg)
        self.time += time.time() - t0
        return ret


def casadify(functn, nd, ny):
    """Casadify a JAX function via JAX-CasADi wrappers
    functn: a JAX function
    nd: the number of input dimensions to the function
    ny: the number of output dimensions
    """
    opts = {"output_dim": [1, ny], "grad_dim": [nd, ny]}
    return ScalarFn(functn, opts=opts)
