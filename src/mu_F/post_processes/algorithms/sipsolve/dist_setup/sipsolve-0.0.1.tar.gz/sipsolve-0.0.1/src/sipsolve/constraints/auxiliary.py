# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.



from dataclasses import dataclass
from typing import Callable
from functools import partial
from jax import jit
import jax.numpy as jnp
from omegaconf import DictConfig

from sipsolve.constraints.utils import ConstraintEvaluatorMinMaxProjection
    
@dataclass(frozen=True)
class UserFeedbackConstraints: 
    r""" 
    This is a class that assumes user feedback is complete and is specified as a collection of binary variables,
    indicating means of refining the previous solution.
    """

    cfg: DictConfig
    n_dim: int
    user_feedback: jnp.ndarray  # shape (n_dim,)
    prev_solution: jnp.ndarray  # shape (2*n_dim,)

    def __post_init__(self):
        assert self.user_feedback.shape == (self.n_dim,), "User feedback must be a binary vector of shape (n_dim,)"
        assert jnp.all(jnp.isin(self.user_feedback, jnp.array([0, 1]))), "User feedback must be binary (0 or 1)"
        assert self.prev_solution.shape == (2 * self.n_dim,), "Previous solution must be of shape (2*n_dim,)"

    def get_constraint_system(
        self,
    ) -> list[Callable]:
        """Return a vector valued function for which:
        :inputs are the batch decisions
        :outputs are evaluations of a given constraint for each datapoint
        """
        n_dim = self.n_dim
        # binary decision representing user feedback
        usr_fb = self.user_feedback
        # previous decision vector
        prev_sol = self.prev_solution   
        # good old big M
        M = jnp.array([self.cfg.constraints.user_feedback.big_M]).squeeze()

        @partial(jit, static_argnums=(1,))
        def get_auxiliary_constraint_lb(x_var, i):
            """Auxilliary constraint function to ensure that the new solution
            is consistent with the user feedback
            """
            prev_x = prev_sol.reshape(2, n_dim)
            g_aux_lb = x_var.reshape(-1,)[i] - prev_x[0, i] - M * usr_fb.reshape(-1,)[i]
            return g_aux_lb
        
        @partial(jit, static_argnums=(1,))
        def get_auxiliary_constraint_ub(x_var, i):
            """Auxilliary constraint function to ensure that the new solution
            is consistent with the user feedback
            """
            prev_x = prev_sol.reshape(2, n_dim)
            g_aux_ub = prev_x[1, i] - x_var.reshape(-1,)[i] - M * (1 - usr_fb.reshape(-1,)[i])
            return g_aux_ub
        
        constraint_system = [jit(partial(get_auxiliary_constraint_lb, i=i)) for i in range(n_dim)]
        constraint_system += [jit(partial(get_auxiliary_constraint_ub, i=i)) for i in range(n_dim)]

        return constraint_system

    def create(
        self,
    ) -> list[Callable]:
        """Returns constraints, such that:
        g_i(x) = x_{i,0} - x_{i,1} <= 0 \for i in {1,...,n_dim}
        """
        return self.get_constraint_system()


def get_user_feedback_constraint_system(
    cfg: DictConfig,
    n_decisions: int,
    user_feedback: jnp.ndarray,
    prev_solution: jnp.ndarray,
):
    if cfg.constraints.auxiliary_constraints.type in auxiliary_constraint_mapping:
        auxiliary_g = auxiliary_constraint_mapping[cfg.constraints.auxiliary_constraints.type](
            cfg, n_decisions, user_feedback, prev_solution
        ).create()
        return [ConstraintEvaluatorMinMaxProjection([aux_g]) for aux_g in auxiliary_g]
    raise NotImplementedError(
        f"auxiliary constraint function specified in config '{cfg.constraints.auxiliary_constraints}' could not be found"
    )
   
auxiliary_constraint_mapping = {
    "UserFeedbackConstraints": UserFeedbackConstraints,
}


if __name__ == "__main__":
    

    def test_user_feedback_constraints():
        from omegaconf import OmegaConf

        cfg = OmegaConf.create(
            {
                "constraints": {
                    "user_feedback": {
                        "big_M": 10
                    }
                }
            }
        )
        n_dim = 2
        user_feedback = jnp.array([1, 1])
        prev_solution = jnp.array([0.0, 0.0, 0.5, 0.5])  # shape (2*n_dim,)

        ufc = UserFeedbackConstraints(cfg, n_dim, user_feedback, prev_solution)
        constraint_system = ufc.create()

        # Test the constraints
        x_var = jnp.array([0.2, 0.2, 1.0, 1.0])  # shape (2*n_dim,)
        evaluations = jnp.array([g(x_var) for g in constraint_system])
        print("Constraint evaluations:", evaluations)

    test_user_feedback_constraints()