# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.

import hydra
import jax.numpy as jnp
import logging
from omegaconf import DictConfig


from sipsolve.utils import bounds_from_config
from sipsolve.run_experiment import experiment

def feedback_integration_exp(cfg: DictConfig):
    # Run the initial experiment
    initial_optimizer, _ = experiment(cfg)
    # Store the previous solution to direct subsequent solutions
    previous_solution = initial_optimizer.feasibility_manager.relaxation_data
    # Integrate feedback into the constrained optimizer by restricting the feasible set
    feedback = get_user_feedback(cfg, previous_solution=previous_solution)
    logging.info(f"User feedback received: {feedback}")
    # Run the experiment again with the updated constraint function
    return experiment(cfg, previous_solution=previous_solution, user_feedback=feedback, iteration=1)

def get_user_feedback(cfg: DictConfig, previous_solution: jnp.ndarray) -> jnp.ndarray:
    # Extract user feedback based on a simple heuristic
    # Here we assume user feedback is given so as to direct the search 
    # towards the region with greatest volume
    previous_solution = previous_solution
    d_bounds = bounds_from_config(cfg, cfg.policy.bounds, bound_factor=1)
    prev_d_sol = previous_solution.reshape(d_bounds.shape)
    bounds_diff = jnp.absolute(d_bounds - prev_d_sol)
    return jnp.argmax(bounds_diff, axis=0)


@hydra.main(config_path="config", config_name="main")
def main(cfg):
    feedback_integration_exp(cfg)

if __name__ == "__main__":
    main()