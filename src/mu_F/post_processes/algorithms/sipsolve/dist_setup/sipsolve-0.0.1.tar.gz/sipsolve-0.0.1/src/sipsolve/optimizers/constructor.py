# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from collections.abc import Callable
from dataclasses import dataclass

import numpy as np
from omegaconf import DictConfig

from sipsolve.optimizers.solvers import casadi_nonconvex_nlpsolver


@dataclass(frozen=True)
class solver_construction:
    """This is used to construct local
    solvers for an NLP problem
    """

    cfg: DictConfig
    solver_type: str

    def create(
        self,
        objective_func: Callable,
        bounds: np.ndarray,
        ineq_constraints_func: list[Callable] | None = None,
        feasibility_problem: bool = False,
    ):
        """This is to be called to actually load the objective function,
        constraints, and bounds into the solver and return a solver object specific to the subproblem
        """
        if self.solver_type == "GeneralInequalityConstrainedNLP":
            return casadi_nonconvex_nlpsolver(
                self.cfg, objective_func, ineq_constraints_func, bounds, feasibility_problem
            )
        raise NotImplementedError(f'Solver type "{self.solver_type}" not implemented')
