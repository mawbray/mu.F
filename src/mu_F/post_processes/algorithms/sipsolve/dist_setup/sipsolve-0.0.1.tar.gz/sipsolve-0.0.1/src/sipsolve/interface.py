# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


import logging
from collections.abc import Callable
from dataclasses import dataclass

from sipsolve.problem_management import SubProblemInterface
from sipsolve.metrics import TimeInSolver
from omegaconf import DictConfig


@dataclass(frozen=True)
class SubProblemIteration:
    cfg: DictConfig
    optimizer: SubProblemInterface
    solver_timing_metrics: TimeInSolver = TimeInSolver()

    def create(self) -> Callable:
        r"""Build the ask-tell interface for constrained Bayesian optimization
        and evaluate the regret on a given subproblem

        Args:
            cfg: Configuration object
            optimizer: An instance of the SubProblemInterface class
        Returns:
            optimizer: with solution of SIP

        """
        logging.info("Starting SIP iterative discretise-feasibility solution method")
        # initialize the counter and convergence flag
        converged = False
        i = 0
        # main optimization loop
        while not converged:
            logging.info(f"Acquisition Round {i + 1}")
            # Solve each subproblem in sequence
            convergence_flag = []
            for k in range(self.get_n_iters_per_step):
                logging.info(f"Subproblem {k + 1}")
                # solve subproblem k and get convergence status
                converge_k, force_terminate = self.solve_subproblem_k()
                convergence_flag.append(converge_k)
                if force_terminate:
                    logging.info("Terminating iteration early due to convergence in P1 solution.")
                    converged = True
                    break
            # overall convergence if all subproblems converged
            converged = all(convergence_flag)
            # check for terminations
            i = self.increment_counter(i)
            if self.check_break(i):
                logging.info(f"Stopping optimization: maximum iterations ({i}) reached.")
                break
        logging.info("Optimization complete.")
        return self.optimizer, self.solver_timing_metrics

    def increment_counter(self, i):
        i += 1
        return i

    def check_break(self, i):
        if i >= self.get_steps:
            return True
        return False

    @property
    def get_n_iters_per_step(self) -> int:
        return self.cfg.policy.n_iters_per_step

    def solve_subproblem_k(self):
        # Ask the optimizer for a new point
        solver = self.optimizer.ask()
        # Evaluate the result of the optimizer
        converged, data = solver()
        # Log time spent in solver
        self.log_time_in_solver(data)
        # Update the subproblem interface with the solution
        _, force_terminate = self.optimizer.tell(data)
        return converged, force_terminate
    
    def log_time_in_solver(self, data):
        # Get the current solver type state: P1 is constraint_manager, which is used when _use_constraint_manager is False
        is_p1_solve = not self.optimizer._use_constraint_manager 
        if is_p1_solve:
            self.solver_timing_metrics.compute(data.get('wall_time', {}))
        

    @property
    def get_steps(self) -> int:
        return self.cfg.policy.n_steps
