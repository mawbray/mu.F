# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from collections.abc import Callable
from dataclasses import dataclass
from math import floor, ceil

from jax import jit
import jax.numpy as jnp

from sipsolve.constraints.utils import ConstraintEvaluatorMinMaxProjection
from sipsolve.problems.constants import A_MAX, A_MIN, M

TensorType = jnp.ndarray


""" Functions to define constraints for test problems """


def _convex_quadratic_constraints() -> list[Callable]:
    def _nlc_func0(x: TensorType) -> TensorType:
        # Example: convex quadratic polynomial, flexible to x dimensionality
        c0 = jnp.sum(x**2, axis=-1, keepdims=True) - 1.5
        return c0

    return [jit(_nlc_func0)]


def _sinusoidal_non_convex_constraints() -> list:
    def _nlc_func0(x: TensorType) -> TensorType:
        # Example: sinusoidal non-convex constraint, flexible to x dimensionality
        x = x.reshape(
            -1,
        )
        c0 = (1/10) * jnp.sum(1/x.shape[0]* jnp.sin(4.0 * jnp.pi * x), axis=0).reshape(-1, 1)
        return c0

    return [jit(_nlc_func0)]

def _rastrigin() -> list:

    def _fn(x: TensorType) -> TensorType:
        x = x.reshape(1,-1)
        A = 10
        return A * x.shape[1] + jnp.sum(x**2 - A * jnp.cos(2 * jnp.pi * x), axis=-1, keepdims=True) - 4.

    return [jit(_fn)]


def _ill_conditioned_cvxquadratic() -> list:
    
    def _ill_cond(x: TensorType) -> TensorType:
        a_ill_conditioned = jnp.logspace(jnp.log10(A_MIN), jnp.log10(A_MAX), x.reshape(-1,).shape[0])
        Q = jnp.diag(a_ill_conditioned)
        return jnp.einsum('...i,ij,...j->...', x, Q, x) - 1.
    
    return [jit(_ill_cond)]


def _ill_conditioned_noncvxquadratic() -> list:
    
    def _ill_cond(x: TensorType) -> TensorType:
        N = x.reshape(-1,).shape[0]
        a_ill_conditioned = jnp.logspace(jnp.log10(A_MIN + (A_MAX - A_MIN)/10), jnp.log10(A_MAX - (A_MAX - A_MIN)/10), N).reshape(-1,)
        signs = jnp.ones(x.reshape(-1,).shape[0]).reshape(-1,)
        signs = signs.at[0:ceil(M*N)].set(-1)  # Set every second element to -1
        Q = jnp.diag(signs*a_ill_conditioned)
        return jnp.einsum('...i,ij,...j->...', x, Q, x).reshape(-1, 1)
    
    return [jit(_ill_cond)]

""" Classes to instantiate constraints for test problems """


@dataclass
class SinusoidalNonConvexConstraints:
    """Get a sinusoidal non-convex function to decribe constraints of
    the form g(x) <= 0.
    """

    def __post_init__(self):
        self.constraints = _sinusoidal_non_convex_constraints()

    def create(self):
        return self.constraints


@dataclass
class ConvexQuadraticConstraints:
    """Get a convex quadratic function to decribe constraints of
    the form g(x) <= 0.
    """

    def __post_init__(self):
        self.constraints = _convex_quadratic_constraints()

    def create(self):
        return self.constraints


@dataclass
class IllCondConvexQuadraticConstraints:
    """Get a convex quadratic function to decribe constraints of
    the form g(x) <= 0.
    """

    def __post_init__(self):
        self.constraints = _ill_conditioned_cvxquadratic()

    def create(self):
        return self.constraints
    
@dataclass
class IllCondNcvxQuadraticConstraints:
    """Get a convex quadratic function to decribe constraints of
    the form g(x) <= 0.
    """

    def __post_init__(self):
        self.constraints = _ill_conditioned_noncvxquadratic()

    def create(self):
        return self.constraints

@dataclass
class RastriginConstraints:
    """Get a Rastrigin function to decribe constraints of
    the form g(x) <= 0.
    """

    def __post_init__(self):
        self.constraints = _rastrigin()

    def create(self):
        return self.constraints

problems_dict = {
    "SinusoidalNonConvex": ConstraintEvaluatorMinMaxProjection(
        constraints=SinusoidalNonConvexConstraints().create()
    ),
    "ConvexQuadratic": ConstraintEvaluatorMinMaxProjection(
        constraints=ConvexQuadraticConstraints().create()
    ),
    "IllCondConvexQuadratic": ConstraintEvaluatorMinMaxProjection(
        constraints=IllCondConvexQuadraticConstraints().create()
    ),
    "IllCondNcvxQuadratic": ConstraintEvaluatorMinMaxProjection(
        constraints=IllCondNcvxQuadraticConstraints().create()
    ),
    "Rastrigin": ConstraintEvaluatorMinMaxProjection(
        constraints=RastriginConstraints().create()
    ),
}

problem_evaluators = {
    "SinusoidalNonConvex": SinusoidalNonConvexConstraints(),
    "ConvexQuadratic": ConvexQuadraticConstraints(),
    "IllCondConvexQuadratic": IllCondConvexQuadraticConstraints(),
    "IllCondNcvxQuadratic": IllCondNcvxQuadraticConstraints(),
    "Rastrigin": RastriginConstraints(),
}

if __name__ == "__main__":
    # Example usage
    problem = SinusoidalNonConvexConstraints()
    constraints = problem.create()
    x = jnp.array([[0.1, 0.2], [0.3, 0.4]])
    d = jnp.array([[1.0, 1.0], [1.0, 1.0]])

    def scaler_fn(x, d):
        return x * d  # Example scaling function

    evaluator = ConstraintEvaluatorMinMaxProjection(constraints[0])
    results = evaluator(x, d, scaler_fn)
    print("Constraint evaluations:", results)

    results_partial = evaluator.partial(d=d, scaler_fn=scaler_fn)(x=x)
    print("Constraint evaluations with partial:", results_partial)
