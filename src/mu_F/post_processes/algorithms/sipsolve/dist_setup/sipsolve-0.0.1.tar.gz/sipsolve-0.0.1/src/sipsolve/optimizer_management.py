# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


import datetime
from functools import partial
import os
import pickle
from collections.abc import Callable
from dataclasses import dataclass
import jax.numpy as jnp
import numpy as np
from omegaconf import DictConfig

from sipsolve.optimizers.constructor import solver_construction
from sipsolve.utils import generate_sobol, scale_sobol, _run_solver_with_initial_guess

@dataclass
class sobol_init_policy:
    x_bounds: jnp.ndarray
    n_data: int

    def __post_init__(self):
        self._gen_control_traj()

    def _gen_control_traj(self):
        """Generate initial data to build the respective models and constraints
        n_data = number of initial data points
        """
        n_dim = self.x_bounds.shape[-1]
        n_data = self.n_data
        self.x_traj = scale_sobol(
            generate_sobol(n_dim, n_data), self.x_bounds[0,], self.x_bounds[1,]
        )

    def create(self):
        """Return Initial data for evaluation
        : N x nx
        """
        return lambda: self.x_traj


def save_initial_data(self, data: dict):
    """Save the policy data. This is an auxiliary helper"""
    cwd = os.getcwd()
    output_dir = os.path.join(cwd, "initial_data")
    os.makedirs(output_dir, exist_ok=True)
    current_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    policy_data_file = os.path.join(output_dir, f"initial_data_{current_time}.pkl")
    with open(policy_data_file, "wb") as f:
        pickle.dump(data, f)


@dataclass(frozen=True)
class constrained_optimizer:
    cfg: DictConfig
    models: list[Callable]
    d_bounds: jnp.ndarray
    initial_guess: jnp.ndarray | None = None
    feasibility_problem: bool = False
    duals: tuple | None = None
    n_g: int = 1

    def _get_bounds(self):
        return jnp.array(self.d_bounds).reshape((2, -1))

    def create(self) -> Callable[[], jnp.ndarray]:
        return self.get_solver()

    def get_solver(self) -> Callable[[], jnp.ndarray]:
        """Create the NLP problem for the constrained optimization problem"""
        if self.feasibility_problem:
            return MaxjFeasibility(
                self.cfg, self.models, self.d_bounds, self.initial_guess, self.feasibility_problem, self.duals
            ).create()

        else:
            return Single_levelNLP(
                self.cfg, self.models, self.d_bounds, self.initial_guess, self.feasibility_problem, self.duals, self.n_g
            ).create()

@dataclass(frozen=True)
class Single_levelNLP:
    r""" This is a wrapper around the casadi solver for a single level NLP problem
    """
    cfg: DictConfig
    models: list[Callable]
    d_bounds: jnp.ndarray
    initial_guess: jnp.ndarray | None = None
    feasibility_problem: bool = False
    duals: tuple | None = None
    n_g: int = 1

    def create(self) -> Callable[[], jnp.ndarray]:
        cfg = self.cfg
        objective_function, *constraint_system = self.models
        d_bounds = self.d_bounds
        feasibility_problem = self.feasibility_problem
        n_g = self.n_g
        policy = solver_construction(cfg, cfg.policy.solver_type).create(
            objective_func=objective_function,
            bounds=d_bounds,
            ineq_constraints_func=constraint_system,
            feasibility_problem=feasibility_problem
        )
        if self.initial_guess is not None and not (self.cfg.constraints.as_penalty or self.cfg.constraints.auxiliary_constraints.as_penalty): # if we have an initial guess for x0
            # we assume duals are also provided
            def policy_noisy_igs():
                n_starts = cfg.policy.n_starts_pos_iter
                additional_noise = cfg.policy.noise_starts
                # generate noisy Igs around the provided initial guess
                noise = additional_noise * np.random.normal(size=(n_starts, self.initial_guess.size))
                init_start = self.initial_guess + noise
                # generate noisy duals around the provided duals
                dual_noise = [additional_noise * np.random.normal(size=(n_starts, dual.shape[1])) for dual in self.duals] if self.duals is not None else None
                # add initial guess for duals
                def add_dual_cols(dual):
                    return jnp.hstack([dual, jnp.array([np.mean(dual, axis=1, keepdims=True)]*n_g).reshape(dual.shape[0], n_g)])
                # append an initial column to the constraint duals
                init_duals = [add_dual_cols(dual + noise) if i > 0 else dual + noise for i, (dual, noise) in enumerate(zip(self.duals, dual_noise))] if self.duals is not None else None
                return policy(initial_x0=jnp.vstack(init_start), duals=init_duals)
            return policy_noisy_igs
        elif self.initial_guess is not None and (self.cfg.constraints.as_penalty or self.cfg.constraints.auxiliary_constraints.as_penalty):
            n_starts = cfg.policy.n_starts_pos_iter
            additional_noise = cfg.policy.noise_starts
            # generate noisy Igs around the provided initial guess
            noise = additional_noise * np.random.normal(size=(n_starts, self.initial_guess.size))
            init_start = self.initial_guess + noise
            return partial(_run_solver_with_initial_guess, policy=policy, initial_x0=init_start)
            # do not use duals
        else:
            return partial(_run_solver_with_initial_guess, policy=policy)

@dataclass(frozen=True)
class MaxjFeasibility:
    """ This separates out a bilevel optimization problem into 
    a series of single level feasibility problems"""
    cfg: DictConfig
    models: list[Callable]
    d_bounds: jnp.ndarray
    initial_guess: jnp.ndarray | None = None
    feasibility_problem: bool = True
    duals: tuple | None = None

    def create(self) -> Callable[[], jnp.ndarray]:
        cfg = self.cfg
        feasibility_problems = self.get_problems()
    
        def solve_call_and_process():
            # iterate through feasibility problems and return the solution
            # that maximally violates the constraints
            max_violation = -jnp.inf
            success = False
            sol = None
            for problem_solver in feasibility_problems:
                result = problem_solver()
                if result[0]:  # if success
                    if result[2] > max_violation: # if this is the most violated constraint
                        max_violation = result[2]
                        sol = result[1]
            # if the maximum violation is within tolerance, we are feasible and terminate
            if max_violation <= cfg.constraints.feasibility_tol:
                success = True
            return success, sol

        return lambda: solve_call_and_process()


    def get_problems(self) -> Callable:
        """Create the solver for the constrained optimization problem"""
        feasibility_problems = [
        ]
        for constraint in self.models:
            feasibility_problems.append(
                Single_levelNLP(
                    self.cfg,
                    [constraint],
                    self.d_bounds,
                    initial_guess=self.initial_guess,
                    feasibility_problem=self.feasibility_problem,
                    duals=self.duals,
                ).create()
            )
        return feasibility_problems
