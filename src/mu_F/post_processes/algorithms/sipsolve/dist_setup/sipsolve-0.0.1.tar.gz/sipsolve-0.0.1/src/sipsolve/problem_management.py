# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


import logging
from collections.abc import Callable
from functools import partial
import jax.numpy as jnp
from jax import nn, jit
from omegaconf import DictConfig

from sipsolve.convergence import ConvergenceTracker
from sipsolve.discretisation import DiscretisationConfig
from sipsolve.optimizer_management import constrained_optimizer
from sipsolve.objectives import get_sip_objective_function
from sipsolve.constraints.constraints import get_sip_constraint_system
from sipsolve.constraints.aggregation import constraint_aggregation_mapping
from sipsolve.utils import _p1_combined_objective, _p1_discretised_constraint, _p1_penalty_function_l2

class P1Manager:
    def __init__(
        self,
        cfg: DictConfig,
        constraints: list[Callable],
        discretisation_scheme: DiscretisationConfig,
        scaling_fn: Callable,
        relaxation_data: list[jnp.ndarray] | None = None,
        penalty_functions: list[Callable] | None = None
    ):
        """Manages the approximation P1 and its update through iterations.
        :constraints: list of constraint functions
        :discretisation_scheme: scheme to generate initial discretisation data
        :scaling_fn: function to scale from [0,1]^n to [d_lower, d_upper]^n
        :relaxation_data: initial discretisation data, if None, will be generated
        """
        self.cfg = cfg
        self.constraints = constraints
        self.discretisation_scheme = discretisation_scheme
        self.scaling_fn = scaling_fn
        self.relaxation_data = relaxation_data
        self.objective_function = None
        self.penalty_set = None
        self.prediction_models = None  # To store prediction functions if needed
        self.penalty_functions = penalty_functions
        self.post_init()

    @property
    def _get_model_bounds_dim(self):
        return self.cfg.constraints.problem_dim

    def post_init(self):
        if self.relaxation_data is None:
            self.relaxation_data = self.discretisation_scheme.create()
            logging.info(f"Initial discretisation data size: {len(self.relaxation_data)}")
        if self.prediction_models is None:
            self.update_models()
        assert len(self.constraints) > 0, "At least one constraint function must be provided."
        
    def update_data(self, new_data: jnp.ndarray):
        """Update datasets with new observations"""
        logging.info("Updating problem data")
        logging.info(f"Before update, feasibility constraint size: {len(self.relaxation_data)}")
        self.relaxation_data = self.combine_data(self.relaxation_data, new_data)
        logging.info(f"After update, feasibility constraint size: {len(self.relaxation_data)}")

    @staticmethod
    def combine_data(old_data: list[jnp.ndarray], new_data: jnp.ndarray) -> list[jnp.ndarray]:
        """Combine two datasets"""
        return old_data + [new_data]
    
    def get_objective_fn(self, penalty_functions: list[Callable] | None = None) -> Callable:
        """Get the objective function for the P1 problem"""
        obj_fn = get_sip_objective_function(self.cfg, self._get_model_bounds_dim)
        if penalty_functions is not None and self.cfg.constraints.auxiliary_constraints.as_penalty:
            logging.info("Using penalty functions in the objective")
            penalty_fns = self.get_penalty_functions(penalty_functions)
            # Refactored from lambda:
            return partial(_p1_combined_objective, obj_fn=obj_fn, penalty_fns=penalty_fns)
        return obj_fn 

    def get_penalty_functions(self, penalty_functions: list[Callable] | None = None) -> list[Callable]:
        """Get the penalty functions for the P1 problem"""
        p_fn = []
        pp = self.cfg.constraints.auxiliary_constraints.penalty_parameter
        l1p = self.cfg.constraints.auxiliary_constraints.l1_penalty_parameter
        for penalty in penalty_functions:
            p_fn_at_discrete_data = self.get_discretised_constraint_system(penalty)
            # Refactored from nested lambda:
            p_fn_l2 = [jit(partial(
                _p1_penalty_function_l2, 
                pp=pp, 
                l1p=l1p, 
                p_fn_at_discrete_data=p_fn_at_discrete_data
            ))]
            p_fn += p_fn_l2
        return p_fn
    
    def get_discretised_constraint_system(self, constraint: Callable) -> list[Callable]:
        """
        Return a list of scalar valued functions to describe constraint system
            at each point in the current discretisation data
        """
        relaxation_data = self.relaxation_data
        scaling_fn = self.scaling_fn
        new_prediction_model_set = []
        for x_val in relaxation_data:
            # Refactored from lambda:
            new_prediction_model_set.append(
                partial(
                    _p1_discretised_constraint,
                    constraint=constraint,
                    x=x_val,
                    scaling_fn=scaling_fn
                )
            )
        return new_prediction_model_set

    def determine_constraint_aggregation(self, constraint_system: list[Callable]) -> list[Callable]:
        """Determine how to aggregate the constraint system into a manageable set of functions
        Here we simply return the full set, but more complex strategies could be implemented
        """
        if self.cfg.constraints.aggregation.method in constraint_aggregation_mapping.keys():
            return constraint_aggregation_mapping[self.cfg.constraints.aggregation.method](cfg=self.cfg, constraints=constraint_system).create()
        raise NotImplementedError(
            f"constraint aggregation strategy specified in config '{self.cfg.constraints.aggregation.method}' could not be found"
        )   
        
    def update_models(self):
        """Update all models with the current data"""
        # set up penalty and constraint sets
        if not self.cfg.constraints.as_penalty:
            penalty_set = self.penalty_functions if self.penalty_functions is not None else []
        else:
            penalty_set = self.penalty_functions if self.penalty_functions is not None else []
            for constraint in self.constraints:
                penalty_set.append(constraint)
        self.penalty_set = penalty_set
        obj_model = self.get_objective_fn(penalty_set)
        # append the objective to a new store of models
        new_prediction_model_set = [obj_model]
        # iteratively redefine the constraint models using fixed structures with the new P1 data
        for constraint in self.constraints:
            constraint_system = self.determine_constraint_aggregation(
                self.get_discretised_constraint_system(constraint)
            )
            new_prediction_model_set += constraint_system
        if self.cfg.constraints.shape_constraints.enable:
            for g in get_sip_constraint_system(self.cfg, self._get_model_bounds_dim):
                new_prediction_model_set.append(g)
        # update the stored models: NOTE obj_model is always ordered first
        self.prediction_models = new_prediction_model_set

    def update(self, new_data: jnp.ndarray):
        """Update both problem data and underlying constraint system"""
        self.update_data(new_data)
        self.update_models()
        return self.prediction_models, self.relaxation_data


class P2Manager:
    def __init__(
        self,
        cfg: DictConfig,
        constraints: list[Callable],
        scaling_fn: Callable,
        relaxation_data: jnp.ndarray | None = None,
    ):
        """Manages iterative updates of the feasibility subproblem P2
        :constraints: list of constraint functions
        :scaling_fn: function to scale from [0,1]^n to [d_lower, d_upper]^n
        :relaxation_data: initial data from P1 to relax constraints, if None, will be generated
         (should be provided from P1)
        """
        self.cfg = cfg
        self.constraints = constraints
        self.scaling_fn = scaling_fn
        self.relaxation_data = relaxation_data
        self.prediction_models = None  # To store prediction functions if needed
        self.post_init()

    def post_init(self):
        assert len(self.constraints) > 0, (
            "At least one constraint must be provided in this formulation"
        )
        assert self.scaling_fn is not None, "Scaling function must be provided for P2Manager"

    def update_data(self, new_data: jnp.ndarray):
        """Update datasets with new solution from P1"""
        self.relaxation_data = new_data

    def update_models(self):
        """Update all models with the current data from the solution of P1"""
        new_prediction_model_set = []
        # append the constraints to create new feasibility problems
        for g in self.constraints:
            new_prediction_model_set.append(
                lambda x, g=g: -g.partial(scaler_fn=self.scaling_fn, d=self.relaxation_data)(
                    x=x
                )
            )
        # update the stored models: we should now solve a feasibility problem for each of these models
        self.prediction_models = new_prediction_model_set

    def update(self, new_data: jnp.ndarray):
        """Update both problem data and underlying constraint system"""
        self.update_data(new_data)
        self.update_models()
        # NOTE in p2, we can actually reduce the constraints into the objective (as they are equality constraints)
        return self.prediction_models, self.relaxation_data


class SubProblemInterface:
    def __init__(
        self,
        cfg: DictConfig,
        constraint_manager: P1Manager,
        feasibility_manager: P2Manager,
        d_bounds: jnp.array,
        x_bounds: jnp.ndarray,
        n_g: int,
    ):
        """Manages the relaxation process between P1 and P2 subproblems
        in a similar way to the ask-tell interface of Trieste
        """
        self.cfg = cfg
        self.feasibility_manager = feasibility_manager
        self.constraint_manager = constraint_manager
        self.d_bounds = d_bounds
        self.x_bounds = x_bounds
        self.n_g = n_g
        self.tracker = ConvergenceTracker(cfg.convergence.tolerance, cfg.convergence.patience)

    @property
    def get_model_input_dimensions(self):
        return self.cfg.constraints.problem_dim

    def track_constraint_convergence(self, solution: jnp.ndarray):
        """Track the convergence of the constraints in P1 and P2"""
        self.tracker.update(solution)
        return self.tracker.has_converged
    
    def get_optimizer(self):
        # Create nonlinear programming solver.
        if not hasattr(self, "_use_constraint_manager"):
            self._use_constraint_manager = True

        if self._use_constraint_manager:
            models = self.constraint_manager.prediction_models
            bounds = self.d_bounds
            self._use_constraint_manager = False
            # use previous solution from P1 as initial guess (stored in P2 manager)
            # if no previous solution, let the solver generate an initial guess via multistart
            # from experiments this has a big impact on solution time.
            initial_x0 = self.feasibility_manager.relaxation_data 
            initial_duals = self.constraint_manager.duals if hasattr(self.constraint_manager, 'duals') else None
        else:
            models = self.feasibility_manager.prediction_models
            bounds = self.x_bounds
            self._use_constraint_manager = True
            # always let the solver generate an initial guess via multistart
            initial_x0 = None
            initial_duals = None

        self.optimizer = constrained_optimizer(
            self.cfg,
            models,
            bounds,
            initial_guess=initial_x0,
            feasibility_problem=self._use_constraint_manager,
            duals=initial_duals,
            n_g=self.n_g
        )
        return self.optimizer.create()

    def ask(self):
        """Constrained optimization to get new points
        or sobol sampling if no model available
        """
        return self.get_optimizer()

    def tell(self, data: dict | jnp.ndarray):
        """
        Update the manager about new problem data
        generated from solving the opposing subproblem
        """
        if self._use_constraint_manager:
            manager = self.constraint_manager
            terminate = False
            data_to_store = data
        else:
            # if we are preparing to solve the feasibility problem, track convergence on P1 solution
            manager = self.feasibility_manager
            data_to_store = data['sol']
            terminate = self.track_constraint_convergence(data_to_store)
            # store duals for next P1 solve
            self.constraint_manager.duals = (data["lam_x"], data["lam_g"])

        _, self.dataset = manager.update(data_to_store)
        return self.dataset, terminate
