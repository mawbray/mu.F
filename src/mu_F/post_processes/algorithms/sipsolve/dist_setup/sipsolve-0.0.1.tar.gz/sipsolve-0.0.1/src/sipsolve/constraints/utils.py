# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.



from typing import Callable
from functools import partial

import jax.numpy as jnp
from jax.scipy.special import logsumexp
from jax import jit, nn

TensorType = jnp.ndarray

""" Wrapper for evaluation of constraints """

class ConstraintEvaluatorMinMaxProjection:
    def __init__(self, constraints: list[Callable]):
        self.constraints = constraints
        assert len(self.constraints) > 0, "At least one constraint function must be provided."
        assert len(self.constraints) == 1, (
            "Only one constraint function is supported in this implementation."
        )

    def __call__(self, x: TensorType, d: TensorType, scaler_fn: Callable) -> jnp.ndarray:
        """Evaluate the constraint after scaling the input"""
        constraints = self.constraints
        x_scaled = scaler_fn(x.reshape(1, -1), d.reshape(1, -1))
        return jnp.array([constraint(x_scaled) for constraint in constraints]).reshape(-1, 1)

    def partial(self, x=None, d=None, scaler_fn=None):
        """Returns a new callable (a partial function) of this instance,
        with any of the __call__ arguments pre-set.
        """
        # Collect the arguments to be fixed
        kwargs = {}
        if x is not None:
            kwargs["x"] = x
        if d is not None:
            kwargs["d"] = d
        if scaler_fn is not None:
            kwargs["scaler_fn"] = scaler_fn

        # functools.partial on an instance (which has a __call__ method)
        # returns a new callable with the specified arguments fixed.
        return partial(self, **kwargs)


def _log_sum_exp_aggregate(x, constraints, b):
    """Aggregates constraints using LogSumExp."""
    g_x_array = jnp.array([g(x) for g in constraints]).reshape(-1,)
    return logsumexp(g_x_array, axis=0, b=b).reshape(1, 1)

def _p_norm_aggregate(x, constraints, p):
    """Aggregates constraints using the p-norm approximation."""
    relu_g_x_pow_p = jnp.array([nn.relu(g(x))**p for g in constraints]).reshape(-1,)
    sum_of_powers = jnp.sum(relu_g_x_pow_p)
    return sum_of_powers.reshape(1, 1)**(1/p)
