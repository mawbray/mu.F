# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from collections.abc import Callable
from dataclasses import dataclass

import jax.numpy as jnp
from jax import jit, nn
from omegaconf import DictConfig


@dataclass(frozen=True)
class BoxInclusion:
    r"""A function to evaluate the multi-output conditional variance
    of multiple independent GP models, as requried for the
    multi-output extension of the variance allocation strategy
    """

    n_dim: int

    def create(self) -> Callable:
        r"""Selection function on boxes

        Args:
            decisions: A jnp.ndarray of shape (2 * n_dim) representing the lower
                       and upper bounds of the box in each dimension

        Returns:
            A function evaluating the negative log volume of the box defined by the decisions

        """
        n_dim = self.n_dim

        # Implementation goes here
        @jit
        def log_sum_volume(inputs: jnp.ndarray) -> jnp.ndarray:
            # NOTE log space transformation runs into numerical issues without applying relu
            # compute the volume of the box defined by inputs
            inputs = jnp.array(inputs).reshape((2, n_dim))
            # make sure the ranges are strictly positive
            ranges = nn.relu(inputs[1, :] - inputs[0, :]) + jnp.array(1.e-5)
            # take the log to avoid numerical issues in high dimensions
            log_sum_volume = jnp.sum(jnp.log(ranges), axis=-1)
            return -log_sum_volume

        return log_sum_volume
    
@dataclass(frozen=True)
class PointWiseErrorMinimisation:
    n_dim: int

    def create(self) -> Callable:
        r""" Selection function on pointwise error 
        Args:
            decisions: A jnp.ndarray of shape (n_dim) representing the decision variables

        Returns:
            A function evaluating the pointwise error of the box defined by the decisions

        """

        @jit
        def pointwise_error(inputs: jnp.ndarray) -> jnp.ndarray:
            # Compute the pointwise error (as last decision variable)
            return inputs.reshape(-1,)[-1]

        return pointwise_error


def get_sip_objective_function(cfg: DictConfig, n_decisions: int):
    objective_index = cfg.policy.objective_target_fn
    if objective_index in objective_mapping:
        return objective_mapping[objective_index](n_dim=n_decisions).create()
    raise NotImplementedError(
        f"objective function specified in config '{objective_index}' could not be found"
    )

objective_mapping = {
    "BoxInclusion": BoxInclusion,
    "PointWiseErrorMinimisation": PointWiseErrorMinimisation,
}
