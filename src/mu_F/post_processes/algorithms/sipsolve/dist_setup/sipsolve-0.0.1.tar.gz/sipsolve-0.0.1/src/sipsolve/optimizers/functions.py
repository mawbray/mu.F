# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from collections.abc import Callable
import logging

import jax.numpy as jnp
from jax import jit, vmap
import numpy as np 
from functools import partial
from casadi import MX, Function, inf, nlpsol, vertcat
from omegaconf import DictConfig
from scipy.stats import qmc

from sipsolve.optimizers.callbacks import casadify
from sipsolve.constants import DEFAULT_WALL_CLOCK_TIME, DEFAULT_ITERATIONS, DEFAULT_TOLERANCE, MU_INIT, WARM_START_MU_INIT, WARM_START_BOUND_PUSH, WARM_START_MULT_BOUND_PUSH, WARM_START_SLACK_BOUND_PUSH

"""
utilities for Casadi NLP solver with inequality constraints
"""

def generate_initial_guess(
    cfg: DictConfig, 
    bounds: jnp.ndarray,
    inequality_constraints: list[Callable] | None = None, 
    objective: Callable | None = None
) -> jnp.ndarray:
    """Here we have defined a Sobol sequence to generate the initial guesses for the NLP solver
    Args:
        cfg: configuration for the optimizer
        bounds: variable bounds (row 0 is lower bounds, 1 is upper bounds)
        inequality_constraints: list of callables for inequality constraints
        objective: callable for the objective function (optional)
    Returns:
        jnp.ndarray: matrix of initial guesses, each row is a starting point
    """
    # method for constrained nlp solution
    n_d = len(bounds[0])
    lower_bound = bounds[0]
    upper_bound = bounds[1]
    n_starts = cfg.policy.n_starts
    # define variable to determine number of draws from sobol sequence
    if inequality_constraints is not None and objective is not None:
        n_draws = cfg.policy.n_draws 
    else:
        n_draws = cfg.policy.n_starts
    # draw sobols
    sobol_samples = qmc.Sobol(d=n_d).random(n_draws)
    scaled_sobol = jnp.array(lower_bound) + (jnp.array(upper_bound) - jnp.array(lower_bound)) * sobol_samples
    # filter for feasible samples if constraints and objective are provided
    if inequality_constraints is not None and objective is not None:
        feasible_samples = []
        g_vals = jnp.ones(scaled_sobol.shape[0], dtype = jnp.int32)
        for constraint in inequality_constraints:
            g_vals *= vmap(constraint)(scaled_sobol).reshape(-1,) <= 0
        feasible_samples = scaled_sobol[jnp.nonzero(g_vals)]        
        # If an objective is provided, we can use it to rank feasible samples
        logging.info(f"Found {len(feasible_samples)} feasible samples out of {n_draws} drawn")
        if len(feasible_samples) >= n_starts and len(feasible_samples) < 10000:
            # Sort feasible samples by objective value and return the best n_starts
            obj_vals = vmap(objective)(feasible_samples)
            sorted_indices = jnp.argsort(obj_vals)
            feasible_samples = feasible_samples[sorted_indices]
            return jnp.array(feasible_samples[:n_starts]).reshape(n_starts, -1)
        elif len(feasible_samples) >= 10000:
            # If too many feasible samples, randomly select n_starts
            obj_vals = vmap(objective)(feasible_samples[:10000])
            sorted_indices = jnp.argsort(obj_vals)
            feasible_samples = feasible_samples[:10000][sorted_indices]
            return jnp.array(feasible_samples[:n_starts]).reshape(n_starts, -1)
        else:
            if cfg.constraints.as_penalty:
                # If not enough feasible samples, return all samples found and hope solver restores feasibility
                logging.warning("Not enough feasible initial guesses found")
                logging.info("Solving feasibility problem to find additional initial guesses")
                additional_feasible = _get_feasible_initial_guess(cfg, inequality_constraints, bounds)
                feasible_samples = jnp.vstack([feasible_samples, additional_feasible])[:n_starts]
                logging.info(f"Total feasible samples after feasibility solve: {len(feasible_samples)}")
                return feasible_samples
            else:
                sobol_samples = qmc.Sobol(d=n_d).random(n_starts)
                scaled_sobol = jnp.array(lower_bound) + (jnp.array(upper_bound) - jnp.array(lower_bound)) * sobol_samples
                logging.warning("Not enough feasible initial guesses found, returning sobol samples with lowest constraint values")
                return jnp.array(scaled_sobol).reshape(-1, n_d)[:n_starts]
    # If no constraints/objective provided, return all samples
    return scaled_sobol

def _get_feasible_initial_guess(
    cfg: DictConfig,
    inequality_constraints: list[Callable] | None = None,
    bounds: jnp.ndarray | None = None,
) -> jnp.ndarray:
    """Solves a feasibility problem to find points interior to the feasible region.

    Args:
        initial_guess (jnp.ndarray): Matrix of initial guesses, each row is a starting point.
        inequality_constraints (list[Callable] | None): List of callables for inequality constraints.
        n_starts (int): Number of feasible initial guesses to return.

    Returns:
        jnp.ndarray: Matrix of feasible initial guesses, or original if none found.
    """

    f_x = jit(lambda x: x.reshape(-1,)[-1].reshape(1,1))
    g_x = [jit(lambda x: constraint(x.reshape(1,-1)[0,:-1]) - x.reshape(1,-1)[0,-1]) for constraint in inequality_constraints] if inequality_constraints is not None else []
    b_x = jnp.hstack([bounds, jnp.hstack([-1000, 1000]).reshape(-1,1)]) if bounds is not None else None
    initial_guess = generate_initial_guess(cfg, b_x)

    all_results = _get_all_results(
        initial_guess,
        f_x,
        g_x,
        b_x,
    )

    feasible_samples = _get_feasible_results(all_results)
    n_starts = cfg.policy.n_starts
    if len(feasible_samples) == 0:
        logging.warning("No feasible initial guesses found, returning original initial guesses")
        return initial_guess[:n_starts]

    return feasible_samples[:n_starts]



def _solve_single_start_unit(
    start_unit: tuple, 
    objective_func: Callable, 
    inequality_constraints: list[Callable] | None, 
    bounds: np.ndarray, 
    n_d: int
) -> dict:
    """
    Unit of work for one initial guess in a multi-start optimization.
    Must be a top-level function for multiprocessing serialization.
    """
    # start_unit is (initial_guess_i, lam_x0_i, lam_g0_i)
    initial_guess_i, lam_x0_i, lam_g0_i = start_unit
    
    # Recreate CASADI callbacks (assumes they are non-serializable across processes)
    f_x = casadify(objective_func, n_d, ny=1)
    g_x = [casadify(constraint, n_d, ny=1) for constraint in inequality_constraints] \
          if inequality_constraints is not None else None

    # casadi_nlp_optimizer_eq_cons is defined in this module, so it's accessible.
    solver, solution = casadi_nlp_optimizer_eq_cons(
        f_x,
        g_x,
        bounds,
        initial_guess_i,
        lam_x0=lam_x0_i,
        lam_g0=lam_g0_i,
    )
    
    # Process result: Convert CasADi objects to NumPy for serialization/return
    stats = solver.stats()
    timing_metrics = {k: v for k, v in stats.items() if k.startswith('t_wall_')}
    
    result = {
        "success": stats["success"],
        "f": solution["f"].full().item(),
        "x": np.array(solution["x"].full()).flatten(),
        "g": np.array(solution["g"].full()) if 'g' in solution else None,
        "lam_x": np.array(solution["lam_x"].full()),
        "lam_g": np.array(solution["lam_g"].full()) if 'lam_g' in solution else None,
        "timing_metrics": timing_metrics, # Return raw timing for aggregation
        "status_message": stats["return_status"],
    }
    
    return result

def _get_all_results(
    initial_guess: np.ndarray,
    objective_func: Callable,
    inequality_constraints: list[Callable] | None,
    bounds: np.ndarray,
    ws_lam_x0: np.ndarray | None = None,
    ws_lam_g0: np.ndarray | None = None,
):
    n_starts = initial_guess.shape[0]
    n_d = initial_guess.shape[1]
    
    # --- Prepare input data for parallel execution ---
    start_units = []
    for i in range(n_starts):
        start_unit = (
            initial_guess[i, :], 
            ws_lam_x0[i,:] if ws_lam_x0 is not None else None,
            ws_lam_g0[i,:] if ws_lam_g0 is not None else None
        )
        start_units.append(start_unit)

    # --- Execute in parallel ---
    # Determine number of processes (e.g., up to the number of starts)
    #num_processes = min(n_starts, cpu_count())
    
    # functools.partial is needed here to fix the arguments of the parallel function.
    worker_func = partial(
        _solve_single_start_unit, 
        objective_func=objective_func, 
        inequality_constraints=inequality_constraints, 
        bounds=bounds, 
        n_d=n_d
    )

    # add parallel execution here instead of a for loop.
    all_results = []
    for worker, start_unit in zip([worker_func]*len(start_units), start_units):
        result = worker(start_unit)
        all_results.append(result)
    
    return all_results


def _get_feasible_results(all_results):
    feasible_results = np.vstack([result["x"][:-1].reshape(1,-1) for result in all_results if result["success"] and result["f"] <= 0])
    return feasible_results


def _get_best_result(all_results):
    # --- Aggregate results and find best solution ---
    best_solution = None
    best_obj = float("inf")
    wall_time_aggregate = {}
    
    # Keep track of the last result in case no solution converges.
    last_result = all_results[-1] if all_results else None

    for i, result in enumerate(all_results):
        if result["success"]:
            current_obj = result["f"]
            if current_obj < best_obj:
                best_obj = current_obj
                best_solution = result
        
        # Aggregate wall time (implements the logic of track_multi_start_timing manually)
        timing_metrics = result['timing_metrics']
        for key, value in timing_metrics.items():
            prev = wall_time_aggregate.get(key, 0.0)
            wall_time_aggregate[key] = prev + (value - prev) / (i + 1)

    if best_solution is None:
        # If no feasible solution found, return the result from the last attempted start
        final_result = last_result
    else:
        final_result = best_solution

    return final_result, wall_time_aggregate

def casadi_multi_start(
    initial_guess: np.ndarray,
    objective_func: Callable,
    inequality_constraints: list[Callable] | None,
    bounds: np.ndarray,
    ws_lam_x0: np.ndarray | None = None,
    ws_lam_g0: np.ndarray | None = None,
):
    """
    Solves an optimization problem using multiple initial points in parallel 
    and returns the solution with minimum objective value.
    """
    
    all_results = _get_all_results(
        initial_guess,
        objective_func,
        inequality_constraints,
        bounds,
        ws_lam_x0,
        ws_lam_g0
    )

    final_result, wall_time_aggregate = _get_best_result(all_results)
        
    # Return the final result dictionary (with NumPy data) and the aggregated wall time
    return final_result, wall_time_aggregate

def casadi_nlp_optimizer_eq_cons(
    f_x: Callable,
    g_x: list[Callable] | None,
    bounds: np.ndarray,
    initial_guess: np.ndarray,
    verbose=True,
    lam_x0: np.ndarray | None = None,
    lam_g0: np.ndarray | None = None,
):
    """Implements an NLP optimizer with inequality constraints

    Args:
        objective: casadi callback for the objective function
        inequality_constraints: list of callables for inequality constraints
        bounds: list of [lower_bounds, upper_bounds]
        initial_guess: numpy array of initial solution guess (optional if use_ilc=True)
        verbose: bool, whether to print progress information

    """
    # Input

    global_lb = bounds[0]
    global_ub = bounds[1]
    n_d = np.shape(global_lb)[0]

    # Get the casadi callbacks required

    # casadi setup
    x = MX.sym("x", n_d, 1)
    j = f_x(x)
    F = Function("F", [x], [j])

    # Handle original inequality constraints
    if g_x is not None:
        # constraints must be scalar functions for this implementation
        g = vertcat(*[constraint(x) for constraint in g_x])
        G = Function("G", [x], [g])

        # Bounds for inequality constraints
        lbg = [-inf] * G.size1_out(0)
        ubg = [0] * G.size1_out(0)

    # Define the NLP
    nlp = {"x": x, "f": F(x)}
    if g_x is not None:
        nlp["g"] = G(x)

     # Determine if warm start is available (using lam_x0 as the indicator)
    is_warm_start = lam_x0 is not None

    # Define the IPOPT solver with options
    options = {
        "ipopt": {
            # --- warm start options ---
            "warm_start_init_point": "yes" if is_warm_start else "no", # Activates the feature
            "mu_init": WARM_START_MU_INIT if is_warm_start else MU_INIT,  # Use a smaller barrier parameter for warm start
            "warm_start_bound_push": WARM_START_BOUND_PUSH,  # Push bounds less aggressively
            "warm_start_mult_bound_push": WARM_START_MULT_BOUND_PUSH, # Push dual bounds less aggressively
            "warm_start_slack_bound_push": WARM_START_SLACK_BOUND_PUSH, # Push slack bounds less aggressively
            # --------------------------
            "hessian_approximation": "limited-memory", # Use limited-memory approximation for Hessian
            "recalc_y": "yes",
            "print_level": 4 if verbose else 0,
            "acceptable_tol": DEFAULT_TOLERANCE,
            "acceptable_obj_change_tol": DEFAULT_TOLERANCE,
            "max_iter": DEFAULT_ITERATIONS,
            "max_wall_time": DEFAULT_WALL_CLOCK_TIME,
            'linear_solver': 'mumps'
        }
    }

    solver = nlpsol("solver", "ipopt", nlp, options)

    # Solve the NLP
    solve_args = {
        "x0": initial_guess,
        "lbx": global_lb,
        "ubx": global_ub,
    }
    if g_x is not None:
        solve_args["lbg"] = lbg
        solve_args["ubg"] = ubg

    # --- warm start duals ---
    if lam_x0 is not None:
        solve_args["lam_x0"] = lam_x0
    if lam_g0 is not None:
        solve_args["lam_g0"] = lam_g0

    solution = solver(**solve_args)
    return solver, solution


