# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


import jax.numpy as jnp
from jax import nn
import numpy as np
from omegaconf import DictConfig, OmegaConf
from scipy.stats import qmc


def bounds_from_config(
    cfg: DictConfig, bounds: list[list[float]], bound_factor: int = 1
) -> jnp.ndarray:
    """Extract bounds from the config."""
    n_dim = cfg.constraints.problem_dim * bound_factor
    bounds = OmegaConf.to_container(bounds)
    assert len(bounds) == 2, "Bounds should be a list of two lists: [lower_bounds, upper_bounds]"
    lb = jnp.array(bounds[0] * n_dim, jnp.float64)
    ub = jnp.array(bounds[1] * n_dim, jnp.float64)
    return jnp.vstack((lb, ub))


def generate_sobol(n_dim: int, n_points: int) -> np.ndarray:
    """Generate Sobol samples in [0, 1]^n_dim"""
    sobol_samples = qmc.Sobol(d=n_dim, scramble=True).random(n_points)
    return sobol_samples


def scale_sobol(
    sobol: np.ndarray, lower_bounds: jnp.ndarray, upper_bounds: jnp.ndarray
) -> jnp.ndarray:
    """Scale Sobol samples to the given bounds.

    Args:
        sobol (np.ndarray): Sobol samples in [0, 1]^d
        lower_bounds (jnp.ndarray): Lower bounds for each dimension
        upper_bounds (jnp.ndarray): Upper bounds for each dimension
    Returns: scaled_samples (jnp.ndarray): Scaled samples within the specified bounds

    """
    return jnp.array(lower_bounds) + (
        jnp.array(upper_bounds) - jnp.array(lower_bounds)
    ) * jnp.array(sobol)


def scaling_fn_box(x: jnp.ndarray, d: jnp.ndarray) -> jnp.ndarray:
    """Scale from [0,1]^n to [d_lower, d_upper]^n"""
    d = d.reshape(2, -1)
    d_lower = d[0, :].reshape(1, -1)
    d_upper = d[1, :].reshape(1, -1)
    return d_lower + (d_upper - d_lower) * x.reshape(1, -1)


def _p1_combined_objective(d, obj_fn, penalty_fns):
    """Combines the main objective function with penalty terms."""
    penalty_sum = jnp.sum(jnp.array([penalty(d) for penalty in penalty_fns]).reshape(-1,), axis=0).squeeze()
    return obj_fn(d) + penalty_sum

def _p1_penalty_function_l2(d, pp, l1p, p_fn_at_discrete_data):
    """Computes the L2 penalized soft-max approximation of the maximum constraint violation."""
    constraint_evals = [p(d) for p in p_fn_at_discrete_data]
    # This maintains the logic of the original lambda expression
    relu_sq_l2 = [nn.relu(eval)**2 for eval in constraint_evals] 
    total_sum = jnp.sum(jnp.array(relu_sq_l2).squeeze())
    return pp * total_sum
    
def _p1_discretised_constraint(d, constraint, x, scaling_fn):
    """Evaluates a single constraint (an instance of ConstraintEvaluatorMinMaxProjection) 
    at a fixed discretisation point x (x=x) using the current decision d as bounds (d=d).
    """
    # This replaces: partial(c, scaler_fn=scaling_fn, x=x)(d=d)
    return constraint(x=x, d=d, scaler_fn=scaling_fn)

def _run_solver_with_initial_guess(policy, initial_x0: jnp.ndarray | None = None) -> jnp.ndarray:
    """Standard execution path: generate initial guess and solve."""
    # policy is the casadi_nonconvex_nlpsolver instance
    if initial_x0 is not None:
        return policy(initial_x0)
    return policy(policy.initial_guess())


scaling_schemes = {
    "Box": scaling_fn_box,
}
