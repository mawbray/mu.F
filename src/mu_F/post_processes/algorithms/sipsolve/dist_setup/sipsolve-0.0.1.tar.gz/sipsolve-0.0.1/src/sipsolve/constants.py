# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


# Default optimization parameters
DEFAULT_WALL_CLOCK_TIME = 120  # seconds
DEFAULT_ITERATIONS = 5000  # iterations
DEFAULT_TOLERANCE = 1e-7  # tolerance
MU_INIT = 1e-6  # initial value for the barrier parameter
WARM_START_MU_INIT = 1e-8  # initial value for the barrier parameter when warm starting
WARM_START_BOUND_PUSH = 1e-9  # push bounds less aggressively
WARM_START_MULT_BOUND_PUSH = 1e-9  # push dual bounds less aggressively
WARM_START_SLACK_BOUND_PUSH = 1e-9  # push slack bounds less aggressively

# DEFAULT DISCRETISATION PARAMETERS
MIN_SAMPLES = 64