# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from collections.abc import Callable
from dataclasses import dataclass

import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from omegaconf import DictConfig

def plotting_format():
    font = {"family": "serif", "weight": "bold", "size": 20}
    plt.rc("font", **font)  # pass in the font dict as kwargs
    plt.rc("axes", labelsize=25)  # fontsize of the x and y label
    plt.rc("axes", linewidth=3)
    plt.rc("axes", labelpad=30)
    plt.rc("xtick", labelsize=20)
    plt.rc("ytick", labelsize=20)


def plot_level_sets_with_constraints(
    objective_func: Callable[[np.ndarray, np.ndarray], np.ndarray],
    constraints: list[Callable[[np.ndarray, np.ndarray], np.ndarray]],
    xlim: tuple,
    ylim: tuple,
    levels: int = 10,
    grid_size: int = 150,
    scatter_points: np.ndarray = None,
    iteration: int = 0,
):
    """Plots contour lines (level sets) of a 2D function, highlighting feasible regions defined by constraints.
    Optionally overlays scatter points (e.g., from a GPJax dataset).

    Parameters
    ----------
        func: Callable[[np.ndarray, np.ndarray], np.ndarray]
            The function to visualize. Should accept two np.ndarray arguments (X, Y).
        constraints: list of Callable[[np.ndarray, np.ndarray], np.ndarray]
            List of constraint functions. Feasible where all g_i(X, Y) <= 0.
        xlim: tuple
            (xmin, xmax) limits for x-axis.
        ylim: tuple
            (ymin, ymax) limits for y-axis.
        levels: int
            Number of contour levels.
        grid_size: int
            Number of points along each axis.
        scatter_points: np.ndarray or None
            Optional. Array of shape (N, 2) for scatter plot overlay.

    """
    plotting_format()
    x = np.linspace(xlim[0], xlim[1], grid_size)
    y = np.linspace(ylim[0], ylim[1], grid_size)
    X, Y = np.meshgrid(x, y)
    points = np.stack([X.ravel(), Y.ravel()], axis=1)

    # Evaluate function
    Z = (
        objective_func(points)
        if callable(getattr(objective_func, "__call__", None))
        and objective_func.__code__.co_argcount == 1
        else objective_func(points[:, 0], points[:, 1])
    )
    Z = Z.reshape(X.shape)

    # Evaluate constraints and build feasible mask
    feasible_mask = np.ones(points.shape[0], dtype=bool)
    for g in constraints:
        g_vals = (
            g(points)
            if callable(getattr(g, "__call__", None)) and g.__code__.co_argcount == 1
            else g(points[:, 0], points[:, 1])
        )
        feasible_mask &= g_vals.squeeze() <= 0
    feasible_mask = feasible_mask.reshape(X.shape)

    plt.figure(figsize=(15, 12))
    contour = plt.contour(X, Y, Z, levels=levels, cmap="viridis")
    plt.clabel(contour, inline=True, fontsize=8)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.title("Level Sets of Function with Feasible Region")
    plt.colorbar(contour)

    # Overlay feasible region
    plt.contourf(X, Y, feasible_mask, levels=[0.1, 1.0], colors=["green", "red"], alpha=0.3)

    # Overlay scatter points if provided
    if scatter_points is not None:
        scatter_points = np.asarray(scatter_points)
        # Check feasibility for each scatter point
        feasible = np.ones(scatter_points.shape[0], dtype=bool)
        for g in constraints:
            g_vals = (
                g(scatter_points)
                if callable(getattr(g, "__call__", None)) and g.__code__.co_argcount == 1
                else g(scatter_points[:, 0], scatter_points[:, 1])
            )
            feasible &= g_vals.squeeze() <= 0
        # Colour code: green for feasible, red for infeasible
        colors = np.where(feasible, "green", "red")
        plt.scatter(
            scatter_points[:, 0],
            scatter_points[:, 1],
            c=colors,
            s=40,
            edgecolors="k",
            label="Samples from inscribed shape",
        )
        plt.legend()

    plt.savefig(f"level_sets_with_constraints_{iteration}.svg", dpi=300)


def visualize_projections(
    samples: jnp.ndarray,
    constraints: list[Callable[[np.ndarray, np.ndarray], np.ndarray]],
    bounds: jnp.ndarray,
    iteration: int = 0,
):
    """Visualizes samples and the feasible box bounds using an enhanced Seaborn PairGrid.

    Args:
        samples (jnp.ndarray): Samples (either original or projected), shape (N, d).
        constraints (list[Callable[[np.ndarray, np.ndarray], np.ndarray]]): List of constraint functions.
        bounds (jnp.ndarray): Bounds array of shape (2, d)
                              where first row is lower bounds and second row is upper bounds.
        title (str): The main title for the figure.

    """
    # --- Data Preparation ---
    plotting_format()
    # Convert to NumPy array for plotting libraries
    samples_np = np.array(samples)
    if samples_np.shape[0] > 1000:
        idx = np.random.choice(samples_np.shape[0], 1000, replace=False)
        samples_np = samples_np[idx]

    if samples_np.ndim != 2:
        raise ValueError("Samples must have shape (N, d).")

    dim = samples_np.shape[1]

    # Create DataFrame with clear column names
    col_names = [f"P{i + 1}" for i in range(dim)]
    df = pd.DataFrame(samples_np, columns=col_names)

    # check feasibility
    samples = np.asarray(samples_np)
    # Check feasibility for each scatter point
    feasible = np.ones(samples.shape[0], dtype=bool)
    for g in constraints:
        g_vals = (
            g(samples)
            if callable(getattr(g, "__call__", None)) and g.__code__.co_argcount == 1
            else -1 * np.ones(samples.shape[0])  # If g is not callable, mark all as infeasible
        )
        feasible &= g_vals.squeeze() <= 0
    # Colour code: green for feasible, red for infeasible
    colors = np.where(feasible, "green", "red")

    lower_bounds = bounds[0]
    upper_bounds = bounds[1]

    # --- Plotting Setup ---
    # Use a larger figure size for PairGrid, especially for high dimensions
    g = sns.PairGrid(df, height=2.5, aspect=1)

    def hide_current_axis(*args, **kwds):
        plt.gca().set_visible(False)

    # --- Mapping Off-Diagonal (Scatter Plots) ---

    def plot_scatter_with_bounds(x, y, **kwargs):
        """Custom scatter plot with rectangular bound overlay."""

        sns.scatterplot(x=x, y=y, edgecolor="k", hue=colors, s=15, alpha=0.8, **kwargs)

        # Get indices for bounds
        i = col_names.index(y.name)
        j = col_names.index(x.name)

        # Overlay the feasible box as a rectangle
        rect = plt.Rectangle(
            (lower_bounds[j], lower_bounds[i]),  # (x_start, y_start)
            upper_bounds[j] - lower_bounds[j],  # width
            upper_bounds[i] - lower_bounds[i],  # height
            fill=False,  # Don't fill
            edgecolor="red",
            linestyle=":",
            linewidth=6,
            zorder=3,
        )
        plt.gca().set_xlim(lower_bounds[j], upper_bounds[j])
        plt.gca().set_ylim(lower_bounds[i], upper_bounds[i])
        plt.gca().add_patch(rect)

    # Apply the custom mappers
    g.map_upper(hide_current_axis)
    g.map_lower(plot_scatter_with_bounds)
    g.map_diag(hide_current_axis)

    for i in range(dim):
        # The diagonal is where the row index (i) equals the column index (i)
        g.axes[i, i].set_visible(False)

    # Improve layout and save
    plt.subplots_adjust(top=0.95, hspace=0.3, wspace=0.3)
    plt.savefig(f"projections_{iteration}.svg", dpi=300)


@dataclass
class visualiser:
    cfg: DictConfig
    models: list[Callable[[np.ndarray, np.ndarray], np.ndarray]]
    x_bounds: jnp.ndarray
    levels: int = 10
    grid_size: int = 150
    iteration: int = 0

    def plot(self, samples: np.ndarray | None = None):
        objective_func, *constraints = self.models

        if self.cfg.constraints.problem_dim == 2:
            xlim = (self.x_bounds[0, 0], self.x_bounds[1, 0])
            ylim = (self.x_bounds[0, 1], self.x_bounds[1, 1])

            plot_level_sets_with_constraints(
                objective_func, constraints, xlim, ylim, self.levels, self.grid_size, samples, iteration=self.iteration
            )
        else:
            visualize_projections(samples, constraints, self.x_bounds, iteration=self.iteration)
