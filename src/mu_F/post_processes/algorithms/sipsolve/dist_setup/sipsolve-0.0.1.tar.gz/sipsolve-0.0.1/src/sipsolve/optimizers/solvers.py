# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


import logging
from abc import ABC
from functools import partial

import numpy as np

from .functions import casadi_multi_start, generate_initial_guess


class solver_base(ABC):
    """This is a base class used to construct local solvers for the feasibility problem"""

    def __init__(self, cfg):
        self.cfg = cfg

    def __call__(self, initial_x0, duals: tuple | None = None):
        return self.process_solve(initial_x0, duals=duals)

    def process_solve(self, initial_x0, duals: tuple | None = None):
        raise NotImplementedError

    def construct_solver(self):
        raise NotImplementedError

    def solve(self):
        raise NotImplementedError

    def get_status(self):
        raise NotImplementedError

    def get_objective(self):
        raise NotImplementedError

    def initial_guess(self):
        raise NotImplementedError


class casadi_nonconvex_nlpsolver(solver_base):
    """A configuration class for nonconvex NLP with general
    inequality constraints only (i.e. no equality constraints)

    """

    def __init__(
        self, cfg, objective_func, inequality_constraints, bounds, feasibility_problem=False
    ):
        super().__init__(cfg)
        self.feasibility_problem = feasibility_problem
        self.construct_solver(objective_func, inequality_constraints, bounds)

    def construct_solver(self, objective_func, inequality_constraints, bounds):
        self.bounds = bounds
        self.inequality_constraints = inequality_constraints
        self.objective_func = objective_func
        

        # formatting for casadi
        if not self.cfg.constraints.as_penalty:
            self.solver = partial(
                casadi_multi_start,
                objective_func=objective_func,
                inequality_constraints=inequality_constraints,
                bounds=bounds,
            )
        else:
            self.solver = partial(
                casadi_multi_start,
                objective_func=objective_func,
                inequality_constraints=None,
                bounds=bounds,
            )

    def initial_guess(self):
        return generate_initial_guess(self.cfg, self.bounds, self.inequality_constraints, self.objective_func)

    def solve(self, initial_x0, duals: tuple | None = None):
        ws_lam_x0 = duals[0] if duals is not None else None
        ws_lam_g0 = duals[1] if duals is not None else None
        
        # Result is now (final_result_dict_with_status, wall_time_aggregate)
        final_result_dict, wall_time = self.solver(
            initial_x0, 
            ws_lam_x0=ws_lam_x0, 
            ws_lam_g0=ws_lam_g0
        )
        
        # Extract the status from the NumPy result dict
        status = final_result_dict["success"]
        objective = final_result_dict["f"]
        sol = final_result_dict["x"]
        constraints = final_result_dict["g"]

        if not status:
            logging.info("--- Solver did not converge ---")
            logging.info(f"Objective: {objective}")
            logging.info(f"Constraints: {constraints}")
            if all(constraints <= 0):
                logging.info("However, all constraints are satisfied.")

                status = True  # Treat as success if constraints are satisfied

        # Return NumPy arrays
        return {
            "success": status,
            "objective": np.array(objective).reshape(1, 1),
            "sol": np.array(sol).reshape(-1),
            "constraints": constraints,
            "lam_x": np.array(final_result_dict["lam_x"]).reshape(1,-1), 
            "lam_g": np.array(final_result_dict["lam_g"]).reshape(1,-1) if final_result_dict["lam_g"] is not None else None,
            "wall_time": wall_time,
            "status_message": final_result_dict["status_message"]
        }

    def process_solve(self, initial_x0 , duals: tuple | None = None):
        results = self.solve(initial_x0, duals=duals)
        logging.info(
            f"Solver success: {results['success']}, Status message: {results['status_message']}"
        )
        logging.info(
            f"Objective value: {results['objective'].squeeze()}"
        )
        logging.info(
            f"Solution: {results['sol']}"
        )
        if self.feasibility_problem:
            return (
                results["success"], np.array(results["sol"]).reshape(-1), -np.array(results["objective"])
            )
        return results["success"], results

