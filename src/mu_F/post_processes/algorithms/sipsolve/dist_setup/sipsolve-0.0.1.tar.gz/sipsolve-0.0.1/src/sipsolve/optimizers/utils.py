# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.



def track_multi_start_timing(solver, wall_time: dict, start_index: int):
    """
    Tracks the timing information for a multi-start optimization process.
    """
    for key, value in solver.stats().items():
        if key.startswith('t_wall_'):
            wall_time[key] = wall_time.get(key, 0)  + (value - wall_time.get(key, 0)) / (start_index + 1)
    return wall_time