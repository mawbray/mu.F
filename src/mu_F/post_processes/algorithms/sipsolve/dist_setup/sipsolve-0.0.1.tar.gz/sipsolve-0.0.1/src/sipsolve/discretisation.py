# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from collections.abc import Callable
from dataclasses import dataclass
from functools import partial

from jax.numpy import ndarray
from sipsolve.utils import generate_sobol, scale_sobol


@dataclass(frozen=True)
class DiscretisationConfig:
    num_samples: int
    bounds: ndarray
    method: str

    def create(self):
        if self.method not in discretisation_methods:
            raise ValueError(f"Discretisation method '{self.method}' not recognized.")
        return discretisation_methods[self.method](self.num_samples, self.bounds)


def sobol_discretisation(num_samples: int, bounds: ndarray, scale_fn: Callable) -> ndarray:
    dim = bounds.shape[1]
    sobol_samples = generate_sobol(dim, num_samples)
    scaled_samples = scale_fn(sobol_samples, bounds[0, :], bounds[1, :])
    return [sample for sample in scaled_samples]


discretisation_methods = {"Sobol": partial(sobol_discretisation, scale_fn=scale_sobol)}
