# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from collections.abc import Callable
from dataclasses import dataclass, field

import jax.numpy as jnp
from sipsolve.discretisation import DiscretisationConfig
from omegaconf import DictConfig
from scipy.stats import beta

@dataclass
class TimeInSolver:
    """Metric to evaluate the time taken by the local solver to solve
    the SIP approximation subproblem.
    """

    metrics: list[str] = field(default_factory=lambda: ['nlp_f', 'nlp_g', 'nlp_grad_f', 'nlp_jac_g', 'total'])
    time_dict: dict = None
    count: int = 0

    def compute(self, wall_time: dict):
        if self.time_dict is None:
            self.time_dict = wall_time
            self.metrics = list(wall_time.keys())
            self.count = 1
        else:
            self.count += 1
            for key, value in wall_time.items():
                prev = self.time_dict.get(key, 0.0)
                self.time_dict[key] = prev + (value - prev) / self.count
        return
    
    def get_results(self):
        if self.time_dict is None:
            raise ValueError("No timing data available. Please run compute() first.")
        return self.time_dict


@dataclass
class ConstraintSatisfaction:
    """Metric to evaluate the constraint satisfaction of a solution
    from an SIP approximation scheme yielded by local NLP solvers.
    """

    cfg: DictConfig
    constraint_fn: Callable
    threshold: float = 0.0
    confidence: float | None = 0.95

    def evaluate(self, solution: jnp.ndarray):
        return solution < self.threshold

    def get_bounds(self, solution: jnp.ndarray):
        """Get bounds for generating samples within the region parameterised by the solution"""
        return solution.reshape(2, -1)

    def generate_samples(self, solution: jnp.ndarray):
        bounds = self.get_bounds(solution)
        return DiscretisationConfig(
            self.cfg.validation.num_samples, bounds=bounds, method=self.cfg.validation.method
        ).create()

    def compute(self, solution: jnp.ndarray) -> jnp.ndarray:
        """Compute the fraction of samples that satisfy the constraint
        from the provided solution.
        """
        samples = self.generate_samples(solution)
        g_x = self.constraint_fn(samples)
        satisfactions = g_x <= self.threshold
        return self.get_constraint_evals(satisfactions, len(samples)), samples

    def get_constraint_evals(self, satisfactions, n_acq):
        if self.confidence is not None:
            f_lb = lower_bound_fn(satisfactions, n_acq, self.confidence)
            f_sa = jnp.mean(satisfactions)
            f_ub = upper_bound_fn(satisfactions, n_acq, self.confidence)
            return jnp.array([f_lb, f_sa, f_ub])
        f_sa = jnp.mean(satisfactions)
        return jnp.array([f_sa])
    
@dataclass
class Volume:
    """Metric to evaluate the volume of the feasible region defined by the solution
    from an SIP approximation scheme yielded by local NLP solvers.
    """

    def compute(self, solution: jnp.ndarray) -> jnp.ndarray:
        """Compute the volume of the feasible region defined by the solution."""
        bounds = solution.reshape(2, -1)
        volume = jnp.prod(jnp.absolute(bounds[1, :] - bounds[0, :]))
        return volume

@dataclass
class PenaltyViolation:
    """Metric to evaluate the penalty violation of a solution
    from an SIP approximation scheme yielded by local NLP solvers.
    """
    penalty_fn: list[Callable]
    def compute(self, solution: jnp.ndarray)-> jnp.ndarray:
        """Compute the penalty violation of the provided solution."""
        penalty_violations = jnp.sum(jnp.array([fn(solution) for fn in self.penalty_fn]).reshape(-1,), axis=0).squeeze()
        return penalty_violations


@dataclass
class Metrics:
    """Class to compute multiple metrics for a solution from an SIP approximation scheme
    """
    metrics: list[Callable] = field(default_factory=lambda: [ConstraintSatisfaction, Volume, PenaltyViolation])
    names: list[str] = field(default_factory=lambda: ['constraints', 'volume', 'penalty_violation'])

    def compute(self, solution: jnp.ndarray) -> dict[str, jnp.ndarray]:
        """Compute all metrics for the provided solution."""
        return {name: metric.compute(solution) for name, metric in zip(self.names, self.metrics)}


def lower_bound_fn(constraint_evals: jnp.ndarray, samples: int, confidence: float) -> jnp.ndarray:
    """Compute the lower bound of the chance constraint satisfaction
    constraint_evals: the constraint satisfaction indicators taking values in {0,1}
    samples: the number of samples we used
    confidence: the desired confidence level
    """
    assert confidence <= 1, "Confidence level must be equal to or less than 1"
    assert confidence >= 0, "Confidence level must be equal to or greater than 0"

    # compute the empirical constraint satisfaction
    F_vioSA = jnp.mean(constraint_evals)

    # compute alpha and beta for the beta distribution
    alpha = samples + 1 - samples * F_vioSA
    b_ta = samples * F_vioSA + 1e-8

    # compute the lower bound of the likelihood as the inverse of the CDF of the beta distribution
    conf = confidence
    betaDist = beta(alpha, b_ta)
    F_LB = betaDist.ppf(conf)

    return 1 - F_LB


def upper_bound_fn(constraint_evals: jnp.ndarray, samples: int, confidence: float) -> jnp.ndarray:
    """Compute the upper bound of the chance constraint satisfaction
    constraint_evals: the constraint satisfaction indicators taking values in {0,1}
    samples: the number of samples we used
    confidence: the desired confidence level
    """
    assert confidence <= 1, "Confidence level must be equal to or less than 1"
    assert confidence >= 0, "Confidence level must be equal to or greater than 0"

    # compute the empiricial constraint satisfaction
    F_vioSA = jnp.mean(constraint_evals)

    # compute alpha and beta for the beta distribution
    alpha = samples - samples * F_vioSA
    b_ta = samples * F_vioSA + 1

    # compute the upper bound of the likelihood as the inverse of the CDF of the beta distribution
    conf = confidence
    betaDist = beta(alpha, b_ta)
    F_LB = betaDist.ppf(1 - conf)

    return 1 - F_LB
