# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from typing import Callable
from functools import partial
from dataclasses import dataclass
from jax import jit
import jax.numpy as jnp
from omegaconf import DictConfig


@dataclass(frozen=True)
class BoundsConstraint:
    r""" """

    n_dim: int

    def get_constraint_system(
        self,
    ) -> list[Callable]:
        """Return a vector valued function for which:
        :inputs are the batch decisions
        :outputs are evaluations of a given constraint for each datapoint
        """
        n_dim = self.n_dim

        @partial(jit, static_argnums=(1,))
        def get_constraint(inputs, i):
            """Upper bound must always be greater than the lower bounds
            g_i(x) = x_{i,0} - x_{i,1} <= 0
            """
            inputs = jnp.array(inputs).reshape((2, n_dim))
            return inputs[0, i] - inputs[1, i]

        return [partial(get_constraint, i=i) for i in range(n_dim)]

    def create(
        self,
    ) -> list[Callable]:
        """Returns constraints, such that:
        g_i(x) = x_{i,0} - x_{i,1} <= 0 \for i in {1,...,n_dim}
        """
        return self.get_constraint_system()

def get_sip_constraint_system(
    cfg: DictConfig,
    n_decisions: int,
):
    constraint_index = cfg.constraints.shape_constraints.type
    if constraint_index in constraint_mapping:
        return constraint_mapping[constraint_index](n_decisions).create()
    raise NotImplementedError(
        f"objective function specified in config '{constraint_index}' could not be found"
    )

constraint_mapping = {"BoundsConstraint": BoundsConstraint}

