# Copyright (C) Secondmind Ltd 2025 - All Rights Reserved
# This document contains confidential and proprietary information
# of Secondmind Ltd. Unauthorized use, disclosure, dissemination,
# or copying of this document or the information herein is strictly
# prohibited. If you are not the intended recipient, please notify
# Secondmind immediately and destroy all copies of this document.


from dataclasses import dataclass
from typing import Callable
from functools import partial
import jax.numpy as jnp
from omegaconf import DictConfig

from sipsolve.constraints.utils import _log_sum_exp_aggregate, _p_norm_aggregate

@dataclass(frozen=True)
class InOutDummyAggregator:
    r"""
    Dummy mapping that returns the constraints as is
    """
    cfg: DictConfig
    constraints: list[Callable]

    def create(self) -> list[Callable]:
        return self.constraints

@dataclass(frozen=True)
class LogSumExpAggregation(InOutDummyAggregator):
    r"""
    Mapping for different constraint aggregation strategies
    """
    def create(self) -> list[Callable]:
        constraints = self.constraints
        b = self.cfg.constraints.aggregation.parameter
        return [partial(_log_sum_exp_aggregate, constraints=constraints, b=b)]

@dataclass(frozen=True)
class pNormAggregation(InOutDummyAggregator):
    r"""
    Mapping for different constraint aggregation strategies
    """

    def __post__init__(self):
        assert self.cfg.constraints.aggregation.parameter > 0, "p-norm parameter must be strictly positive"
        assert self.cfg.constraints.aggregation.parameter < jnp.inf, "p-norm parameter must be finite"
        assert self.cfg.constraints.aggregation.parameter % 2 == 0, "p-norm parameter must not have a residual when divided by 2"

    def create(self) -> list[Callable]:
        constraints = self.constraints
        p = self.cfg.constraints.aggregation.parameter
        return [partial(_p_norm_aggregate, constraints=constraints, p=p)]


constraint_aggregation_mapping = {
    "None": InOutDummyAggregator,  # No aggregation, return as is
    "LogSum": LogSumExpAggregation,  # Aggregate all constraints into one smooth approximator of max{g_i(x)}
    "PNorm": pNormAggregation,  # Aggregate all constraints into one p-norm approximator of max{g_i(x)}
}