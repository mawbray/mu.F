from deus.activities.solvers.evaluators.smescores.evaluator import \
    SMEScoreEvaluator
