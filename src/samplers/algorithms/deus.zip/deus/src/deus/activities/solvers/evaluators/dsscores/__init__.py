from deus.activities.solvers.evaluators.dsscores.evaluator import \
    DSScoreEvaluator
