from deus.activities.solvers.evaluators.lkhd.evaluator import \
    LogLkhdEvaluator
