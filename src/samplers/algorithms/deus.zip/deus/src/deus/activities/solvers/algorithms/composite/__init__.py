import abc

from deus.activities.solvers.algorithms import CompositeAlgorithm
from deus.activities.solvers.algorithms.composite.ns_global import \
    NestedSamplingWithGlobalSearch
