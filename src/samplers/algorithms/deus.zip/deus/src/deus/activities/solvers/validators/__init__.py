from deus.activities.solvers.validators.ds import ValidatorForDSSolver
from deus.activities.solvers.validators.pe import ValidatorForPESolver
from deus.activities.solvers.validators.sme import ValidatorForSMESolver
