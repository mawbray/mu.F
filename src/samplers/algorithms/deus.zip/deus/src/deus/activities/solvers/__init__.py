from deus.activities.solvers.ds_ns_solver import \
    DesignSpaceSolverUsingNS
from deus.activities.solvers.pe_ns_solver import \
    ParameterEstimationSolverUsingNS
from deus.activities.solvers.sme_ns_solver import \
    SetMembershipEstimationSolverUsingNS
